import test from 'node:test';
import assert from 'node:assert/strict';
import { validateBackup } from '../src/backup.js';

const product = { id: 'burger-1', name: 'Vovô Burger', category: 'classicos', description: 'Carne e queijo', prices: [{ label: 'Único', price: 15.5 }], image: '' };
const settings = { storeName: 'Lanche do Vovô', tagline: 'Feito com carinho.', whatsapp: '', deliveryFee: '0', minOrder: '0', deliveryEnabled: true, pickupEnabled: true, logo: '/logo-lanche-do-vovo.jpg', address: '', openingHours: '', heroImages: [] };
const validBackup = () => ({ app: 'Lanche do Vovô', version: 2, settings: { ...settings }, products: [{ ...product, prices: product.prices.map((price) => ({ ...price })) }], cart: [], categories: [{ id: 'all', label: 'Tudo', visible: true }, { id: 'classicos', label: 'Clássicos', visible: true }], likeCounts: { 'burger-1': 2 } });

test('aceita backup consistente com categorias e curtidas', () => {
  const input = validBackup();
  assert.equal(validateBackup(input), input);
});

test('aceita backup antigo sem categorias, carrinho ou curtidas', () => {
  const input = { settings: { ...settings }, products: [{ ...product }] };
  assert.equal(validateBackup(input), input);
});

test('rejeita estrutura que não é um backup', () => {
  assert.throws(() => validateBackup({ products: [], settings: [] }), /backup válido/i);
});

test('rejeita IDs de produto repetidos', () => {
  const input = validBackup();
  input.products.push({ ...input.products[0] });
  assert.throws(() => validateBackup(input), /IDs de produto duplicados/i);
});

test('rejeita opções de preço com nomes repetidos ignorando acentos', () => {
  const input = validBackup();
  input.products[0].prices.push({ label: 'Unico', price: 16 });
  assert.throws(() => validateBackup(input), /produtos ou preços inválidos/i);
});

test('rejeita produtos associados a categoria inexistente no backup', () => {
  const input = validBackup();
  input.products[0].category = 'categoria-nao-incluida';
  assert.throws(() => validateBackup(input), /categorias ausentes/i);
});

test('rejeita taxa de entrega negativa', () => {
  const input = validBackup();
  input.settings.deliveryFee = '-2';
  assert.throws(() => validateBackup(input), /valores de entrega inválidos/i);
});

test('rejeita contador de curtidas inválido', () => {
  const input = validBackup();
  input.likeCounts['burger-1'] = -1;
  assert.throws(() => validateBackup(input), /contadores de curtidas inválidos/i);
});
