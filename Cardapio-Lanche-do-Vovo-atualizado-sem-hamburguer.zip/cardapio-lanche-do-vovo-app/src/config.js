import { CATEGORIES } from './data.js';

export const KEYS = {
  products: 'ldv_products_v1',
  settings: 'ldv_settings_v1',
  cart: 'ldv_cart_v1',
  categories: 'ldv_categories_v1',
  likes: 'ldv_likes_v1',
};

export const DEFAULT_CATEGORIES = CATEGORIES.map((item) => ({ ...item, visible: true }));
export const ADMIN_PASSWORD = 'vovo2026';

export const DEFAULT_SETTINGS = {
  storeName: 'Lanche do Vovô',
  tagline: 'Feito na hora. Feito com carinho.',
  whatsapp: '',
  deliveryFee: '0',
  minOrder: '0',
  deliveryEnabled: true,
  pickupEnabled: true,
  logo: '/logo-lanche-do-vovo.jpg',
  address: '',
  openingHours: 'Todos os dias · consulte a disponibilidade',
  heroImages: [],
  promotions: [],
};

export const normalizeSettings = (value) => {
  const stored = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const settings = { ...DEFAULT_SETTINGS, ...stored };
  for (const key of ['storeName', 'tagline', 'whatsapp', 'logo', 'address', 'openingHours']) {
    if (typeof settings[key] !== 'string') settings[key] = DEFAULT_SETTINGS[key];
  }
  for (const key of ['deliveryFee', 'minOrder']) {
    const amount = Number(settings[key]);
    if ((typeof settings[key] !== 'string' && typeof settings[key] !== 'number') || !Number.isFinite(amount) || amount < 0) settings[key] = DEFAULT_SETTINGS[key];
  }
  for (const key of ['deliveryEnabled', 'pickupEnabled']) {
    if (typeof settings[key] !== 'boolean') settings[key] = DEFAULT_SETTINGS[key];
  }
  settings.heroImages = Array.isArray(settings.heroImages) ? settings.heroImages.filter((item) => typeof item === 'string').slice(0, 10) : [];
  settings.promotions = Array.isArray(settings.promotions) ? settings.promotions.filter((item) => item && typeof item === 'object').slice(0, 6).map((item) => ({ id: String(item.id || `promo-${Math.random().toString(36).slice(2, 8)}`), title: String(item.title || ''), description: String(item.description || ''), kicker: String(item.kicker || ''), buttonLabel: String(item.buttonLabel || 'Ver cardápio'), image: typeof item.image === 'string' ? item.image : '', productId: String(item.productId || ''), active: item.active !== false, tone: String(item.tone || 'gold') })) : [];
  if (!settings.deliveryEnabled && !settings.pickupEnabled) settings.pickupEnabled = true;
  return settings;
};

export const money = (value) => Number(value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
export const parseMoney = (value) => Number(String(value ?? '').replace(',', '.')) || 0;

export const readStorage = (key, fallback) => {
  try {
    const value = localStorage.getItem(key);
    if (!value) return fallback;
    const parsed = JSON.parse(value);
    if (Array.isArray(fallback)) return Array.isArray(parsed) ? parsed : fallback;
    if (fallback && typeof fallback === 'object') return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : fallback;
    return parsed;
  } catch {
    return fallback;
  }
};

export const slug = () => `produto-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
