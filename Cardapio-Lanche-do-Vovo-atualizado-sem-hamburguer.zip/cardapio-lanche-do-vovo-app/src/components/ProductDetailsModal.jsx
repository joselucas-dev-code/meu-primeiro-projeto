import { useEffect, useState } from 'react';
import { ArrowLeft, PlayCircle, ShoppingBag, X } from 'lucide-react';
import { money } from '../config.js';
import { getVideoFile } from '../utils/media.js';
import { ImagePlaceholder, ModalShell } from './shared.jsx';

export function ProductDetailsModal({ product, categories = [], onClose, onAdd }) {
  const [videoUrl, setVideoUrl] = useState('');
  const [videoError, setVideoError] = useState('');
  const [selected, setSelected] = useState(0);
  const options = product.prices?.length ? product.prices : [{ label: 'Único', price: 0 }];
  useEffect(() => {
    let url = '';
    let cancelled = false;
    setVideoError('');
    setVideoUrl('');
    if (product.videoUrl) {
      setVideoUrl(product.videoUrl);
      return undefined;
    }
    if (!product.videoId) return undefined;
    getVideoFile(product.videoId).then((record) => {
      if (!record?.blob) { setVideoError('O vídeo não está disponível neste navegador.'); return; }
      const nextUrl = URL.createObjectURL(record.blob);
      if (cancelled) URL.revokeObjectURL(nextUrl);
      else { url = nextUrl; setVideoUrl(nextUrl); }
    }).catch(() => setVideoError('Não foi possível carregar o vídeo de montagem.'));
    return () => { cancelled = true; if (url) URL.revokeObjectURL(url); };
  }, [product.videoId, product.videoUrl]);
  const categoryName = categories.find((item) => item.id === product.category)?.label || 'Da casa';
  return <ModalShell onClose={onClose} wide className="product-details-modal"><div className="details-topline"><span className="eyebrow">CONHEÇA SEU FAVORITO</span><button className="icon-button" onClick={onClose} aria-label="Fechar detalhes"><X/></button></div>
    <div className="product-details-layout"><div className="details-visual">{product.image ? <img src={product.image} alt={product.name}/> : <ImagePlaceholder category={product.category}/>}<span className="details-category">{categoryName}</span></div>
      <div className="details-copy"><div className="eyebrow">{product.badge || 'PREPARADO NA HORA'}</div><h2>{product.name}</h2><p className="details-description">{product.details || product.description || 'Um dos favoritos da casa, preparado na hora com todo o carinho.'}</p>
        <div className="details-price-list"><h3>Opções disponíveis</h3>{options.map((option, optionIndex) => <button type="button" key={`${option.label}-${optionIndex}`} className={`details-price-option ${selected === optionIndex ? 'active' : ''}`} onClick={() => setSelected(optionIndex)}><span><b>{option.label}</b>{selected === optionIndex && <small>Selecionado</small>}</span><strong>{money(option.price)}</strong></button>)}</div>
        {product.ingredients && <div className="details-info-block"><h3>Ingredientes</h3><p>{product.ingredients}</p></div>}
        {product.allergens && <div className="details-info-block"><h3>Informações sobre alergênicos</h3><p>{product.allergens}</p></div>}
        {product.preparation && <div className="details-info-block"><h3>Como é preparado</h3><p>{product.preparation}</p></div>}
        <button className="primary-button details-add-button" onClick={() => { onAdd(product, options[selected]); onClose(); }}><ShoppingBag size={17}/> Adicionar ao pedido — {money(options[selected].price)}</button>
      </div></div>
    {(videoUrl || videoError) && <section className="details-video-section"><div><span className="eyebrow"><PlayCircle size={14}/> POR TRÁS DO SABOR</span><h3>Veja a montagem</h3><p>Confira o preparo deste produto.</p></div>{videoUrl ? <video src={videoUrl} controls playsInline preload="metadata" aria-label={`Vídeo da montagem de ${product.name}`}/> : <p className="video-load-error">{videoError}</p>}</section>}
    <button className="details-back" onClick={onClose}><ArrowLeft size={15}/> Voltar ao cardápio</button>
  </ModalShell>;
}
