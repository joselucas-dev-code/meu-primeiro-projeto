import { useEffect, useState } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';

const FALLBACK_PROMOS = [
  { id: 'vovo-destaques', title: 'Tem sabor esperando por você', description: 'Confira os clássicos, os especiais e encontre seu próximo lanche favorito.', buttonLabel: 'Explorar cardápio', tone: 'gold' },
  { id: 'vovo-feito-na-hora', title: 'Feito na hora, com carinho', description: 'Escolha seu pedido e monte a combinação do seu jeito.', buttonLabel: 'Ver produtos', tone: 'red' },
];

export function PromotionsCarousel({ promotions = [], products = [], onOpenProduct, onBrowse }) {
  const hasConfiguredPromotions = promotions.length > 0;
  const slides = hasConfiguredPromotions ? promotions.filter((item) => item.active !== false) : FALLBACK_PROMOS;
  const [index, setIndex] = useState(0);
  useEffect(() => setIndex(0), [slides.length]);
  useEffect(() => {
    if (slides.length < 2) return undefined;
    const timer = window.setInterval(() => setIndex((current) => (current + 1) % slides.length), 5500);
    return () => window.clearInterval(timer);
  }, [slides.length]);
  if (!slides.length) return null;
  const active = slides[Math.min(index, slides.length - 1)];
  const linkedProduct = products.find((product) => product.id === active.productId && product.active !== false);
  const go = (direction) => setIndex((current) => (current + direction + slides.length) % slides.length);
  return <section className={`promotions-shell promo-tone-${active.tone || 'gold'}`} aria-label="Promoções e destaques">
    <div className="promotions-heading"><div><span className="eyebrow"><Sparkles size={14}/> NOVIDADES DO VOVÔ</span><h2>Ofertas e <em>destaques</em></h2></div><span className="promo-count">{String(index + 1).padStart(2, '0')} <i>/</i> {String(slides.length).padStart(2, '0')}</span></div>
    <article className={`promo-slide ${active.image ? 'has-promo-image' : ''}`} key={active.id || index}>
      {active.image && <img className="promo-image" src={active.image} alt="" loading="lazy"/>}
      <div className="promo-slide-shade"/>
      <div className="promo-copy"><span className="promo-kicker">{active.kicker || (linkedProduct ? 'DESTAQUE DA CASA' : 'LANCHES DO VOVÔ')}</span><h3>{active.title || 'Uma delícia da casa'}</h3><p>{active.description || 'Confira esse destaque e escolha seu próximo favorito.'}</p>
        <button className="promo-cta" onClick={() => linkedProduct ? onOpenProduct(linkedProduct) : onBrowse()}>{active.buttonLabel || 'Ver cardápio'} <ArrowRight size={16}/></button>
      </div>
      {!active.image && <div className="promo-food-art" aria-hidden="true"><span>🍔</span><i>🍟</i><b>🥤</b></div>}
    </article>
    {slides.length > 1 && <div className="promo-controls"><button type="button" onClick={() => go(-1)} aria-label="Promoção anterior"><ChevronLeft size={18}/></button><div className="promo-dots">{slides.map((slide, dotIndex) => <button type="button" key={slide.id || dotIndex} className={dotIndex === index ? 'active' : ''} aria-label={`Mostrar promoção ${dotIndex + 1}`} onClick={() => setIndex(dotIndex)}/>)}</div><button type="button" onClick={() => go(1)} aria-label="Próxima promoção"><ChevronRight size={18}/></button></div>}
  </section>;
}
