import { useEffect, useState } from 'react';
import { ChevronDown, Heart, Plus, ArrowUpRight } from 'lucide-react';
import { CATEGORIES } from '../data.js';
import { money } from '../config.js';
import { ImagePlaceholder } from './shared.jsx';

export function ProductCard({ product, categories = CATEGORIES, onAdd, onDetails, isFavorite, likeCount = 0, onFavorite }) {
  const [selected, setSelected] = useState(0);
  const options = product.prices?.length ? product.prices : [{ label: 'Único', price: 0 }];
  useEffect(() => { if (selected >= options.length) setSelected(0); }, [options.length, selected]);
  const price = options[selected];
  return <article className="product-card">
    <div className="product-image-wrap">
      {product.image ? <img className="product-image" src={product.image} alt={product.name} loading="lazy"/> : <ImagePlaceholder category={product.category}/>}
      {product.badge && <span className="product-badge">{product.badge}</span>}
      <button className={`favorite-button ${isFavorite ? 'favorite-active' : ''}`} aria-label={isFavorite ? 'Descurtir produto' : 'Curtir produto'} onClick={onFavorite}><Heart size={17} fill={isFavorite ? 'currentColor' : 'none'}/><span className='like-count'>{likeCount}</span></button>
    </div>
    <div className="product-info"><div className="product-category">{categories.find((item) => item.id === product.category)?.label || CATEGORIES.find((item) => item.id === product.category)?.label || 'Da casa'}</div><h3>{product.name}</h3><p>{product.description || 'Um dos favoritos da casa, preparado na hora.'}</p>
      <button type="button" className="product-details-link" onClick={() => onDetails?.(product)}>Ver detalhes <ArrowUpRight size={14}/></button>
      {options.length > 1 && <label className="option-select"><span>Escolha sua opção</span><span className="select-wrap"><select value={selected} onChange={(e) => setSelected(Number(e.target.value))} aria-label={`Tamanho de ${product.name}`}>{options.map((option, index) => <option key={`${option.label}-${index}`} value={index}>{option.label}</option>)}</select><ChevronDown size={14}/></span></label>}
      <div className="product-bottom"><div className="price-block"><small>{options.length > 1 ? 'A partir de' : 'Preço'}</small><strong>{money(Math.min(...options.map((item) => Number(item.price) || 0)))}</strong>{options.length > 1 && <span>Selecionado: {money(price.price)}</span>}</div><button className="add-button" aria-label={`Adicionar ${product.name} ao carrinho`} onClick={() => onAdd(product, price)}><Plus size={20}/></button></div>
    </div>
  </article>;
}
