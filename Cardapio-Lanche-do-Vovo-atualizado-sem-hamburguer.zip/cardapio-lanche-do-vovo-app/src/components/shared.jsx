import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Eye, EyeOff, LockKeyhole } from 'lucide-react';
import { ADMIN_PASSWORD } from '../config.js';

export function ImagePlaceholder({ category = 'classicos', compact = false }) {
  const food = category === 'shakes' ? '🥤' : category === 'porcoes' ? '🍟' : category === 'crispy' ? '🍗' : '🍔';
  return <div className={`image-placeholder ${compact ? 'compact' : ''}`}><span className="placeholder-glow"/><span className="food-emoji">{food}</span><span className="placeholder-label">Sua foto aqui</span></div>;
}

export function ModalShell({ children, onClose, wide = false, className = '' }) {
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => { const old = document.body.style.overflow; document.body.style.overflow = 'hidden'; const handler = (event) => { if (event.key === 'Escape') closeRef.current(); }; window.addEventListener('keydown', handler); return () => { document.body.style.overflow = old; window.removeEventListener('keydown', handler); }; }, []);
  return <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section className={`modal-panel ${wide ? 'modal-wide' : ''} ${className}`}>{children}</section></div>;
}

export function PasswordGate({ onClose, onSuccess }) {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const submit = (event) => {
    event.preventDefault();
    if (password === ADMIN_PASSWORD) { setError(''); onSuccess(); }
    else { setPassword(''); setError('Senha incorreta.'); }
  };
  return <ModalShell onClose={onClose} className="password-gate-modal"><div className="password-gate-inner"><div className="password-gate-symbol"><LockKeyhole size={21}/></div><div className="eyebrow">ACESSO DA LOJA</div><h2>Área administrativa</h2><p>Digite a senha para editar produtos e configurações.</p><form onSubmit={submit}><label>Senha<div className="password-input-wrap"><input autoFocus required type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Digite a senha"/><button type="button" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}>{showPassword ? <EyeOff size={17}/> : <Eye size={17}/>}</button></div></label>{error && <p className="password-error" role="alert">{error}</p>}<button className="primary-button full-width" type="submit">Continuar <ArrowRight size={16}/></button><button className="outline-button full-width password-cancel" type="button" onClick={onClose}>Cancelar</button></form><p className="password-warning">Esta senha é uma barreira visual no navegador, não substitui autenticação no servidor.</p></div></ModalShell>;
}


export function StoreLoginPage({ storeName = 'Lanche do Vovô', logo = '/logo-lanche-do-vovo.jpg', onBack, onSuccess }) {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const submit = (event) => {
    event.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setError('');
      onSuccess();
      return;
    }
    setPassword('');
    setError('Senha incorreta. Confira e tente novamente.');
  };

  return <main className="store-access-shell">
    <div className="store-access-grid" aria-hidden="true"/>
    <div className="store-access-orb store-access-orb-one" aria-hidden="true"/>
    <div className="store-access-orb store-access-orb-two" aria-hidden="true"/>
    <a className="store-access-brand" href="#/" onClick={(event) => { event.preventDefault(); onBack(); }}>
      <img src={logo || '/logo-lanche-do-vovo.jpg'} alt="" onError={(event) => { event.currentTarget.src = '/logo-lanche-do-vovo.jpg'; }}/>
      <span><b>{storeName}</b><small>PAINEL EXCLUSIVO DA LOJA</small></span>
    </a>
    <section className="store-access-card" aria-labelledby="store-access-title">
      <div className="store-access-icon"><LockKeyhole size={24}/></div>
      <span className="store-access-eyebrow"><i/> AMBIENTE ADMINISTRATIVO</span>
      <h1 id="store-access-title">Oi, Vovô! <em>Vamos cuidar da loja?</em></h1>
      <p>Entre para atualizar o cardápio, mexer nos preços, organizar as fotos e ajustar as configurações.</p>
      <form onSubmit={submit} className="store-access-form">
        <label htmlFor="store-access-password">Senha de acesso</label>
        <div className="store-access-password-wrap">
          <LockKeyhole size={17}/>
          <input id="store-access-password" autoFocus required type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Digite sua senha" autoComplete="current-password"/>
          <button type="button" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}>{showPassword ? <EyeOff size={18}/> : <Eye size={18}/>}</button>
        </div>
        {error && <p className="store-access-error" role="alert">{error}</p>}
        <button className="store-access-submit" type="submit">Entrar no painel <ArrowRight size={18}/></button>
      </form>
      <button className="store-access-back" type="button" onClick={onBack}>← Voltar para o cardápio do cliente</button>
    </section>
    <footer className="store-access-footer"><span>🍔</span> Feito na hora. Feito com carinho.</footer>
  </main>;
}
