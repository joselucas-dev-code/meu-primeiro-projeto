import { ArrowRight, Minus, Plus, Smartphone, Trash2, Truck, X } from 'lucide-react';
import { money, parseMoney } from '../config.js';
import { ImagePlaceholder } from './shared.jsx';

export function CartDrawer({ cart, subtotal, settings, onClose, onChangeQty, onRemove, onBrowse, onCheckout }) {
  const deliveryFee = parseMoney(settings.deliveryFee);
  const minimum = parseMoney(settings.minOrder);
  return <div className="drawer-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><aside className="cart-drawer">
    <div className="drawer-header"><div><div className="eyebrow">QUASE LÁ</div><h2>Seu pedido <span>({cart.reduce((sum, item) => sum + item.qty, 0)})</span></h2></div><button className="icon-button" onClick={onClose} aria-label="Fechar carrinho"><X/></button></div>
    {cart.length === 0 ? <div className="cart-empty"><div className="empty-cart-art">🛍️</div><h3>Seu carrinho está esperando</h3><p>Escolha algo gostoso no cardápio e ele aparece aqui.</p><button className="primary-button" onClick={onBrowse}>Explorar cardápio <ArrowRight size={16}/></button></div> : <>
      <div className="cart-items">{cart.map((item) => <div className="cart-item" key={item.key}><div className="cart-item-image">{item.image ? <img src={item.image} alt=""/> : <ImagePlaceholder category={item.category} compact/>}</div><div className="cart-item-main"><b>{item.name}</b><small>{item.variant}</small><strong>{money(item.price * item.qty)}</strong><div className="qty-control"><button onClick={() => onChangeQty(item.key, -1)} aria-label="Diminuir quantidade"><Minus size={13}/></button><span>{item.qty}</span><button onClick={() => onChangeQty(item.key, 1)} aria-label="Aumentar quantidade"><Plus size={13}/></button></div></div><button className="remove-item" aria-label={`Remover ${item.name}`} onClick={() => onRemove(item.key)}><Trash2 size={16}/></button></div>)}</div>
      <div className="cart-summary"><div><span>Subtotal</span><b>{money(subtotal)}</b></div>{deliveryFee > 0 && <div><span>Entrega (estimada)</span><b>{money(deliveryFee)}</b></div>}<p><Truck size={15}/> {settings.deliveryEnabled && settings.pickupEnabled ? 'Entrega ou retirada disponíveis' : settings.deliveryEnabled ? 'Entrega disponível' : 'Retirada no local'} · taxa confirmada pela loja</p>{minimum > 0 && subtotal < minimum && <div className="minimum-alert">Pedido mínimo de {money(minimum)}. Faltam {money(minimum - subtotal)}.</div>}<div className="cart-total"><span>Total estimado</span><strong>{money(subtotal + deliveryFee)}</strong></div><button className="primary-button full-width" disabled={minimum > 0 && subtotal < minimum} onClick={onCheckout}>Continuar pedido <ArrowRight size={17}/></button><small className="whatsapp-note"><Smartphone size={14}/> Você confirma o pedido pelo WhatsApp</small></div>
    </>}
  </aside></div>;
}
