import { useEffect, useRef, useState } from 'react';
import { Check, ImagePlus, Plus, Trash2, X } from 'lucide-react';
import { CATEGORIES } from '../data.js';
import { imageToDataUrl } from '../utils/images.js';
import { ImagePlaceholder, ModalShell } from './shared.jsx';
import { getVideoFile, removeVideoFile, saveVideoFile } from '../utils/media.js';

export function ProductEditor({ product, categories = CATEGORIES, onClose, onSave }) {
  const [draft, setDraft] = useState(() => ({ ...product, prices: (product.prices || []).map((item) => ({ ...item })) }));
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [videoBusy, setVideoBusy] = useState(false);
  const [videoUrl, setVideoUrl] = useState(product.videoUrl || '');
  const [videoName, setVideoName] = useState('');
  const photoRef = useRef(null);
  const videoRef = useRef(null);
  useEffect(() => {
    let localUrl = ''; let cancelled = false;
    if (product.videoUrl) { setVideoUrl(product.videoUrl); return undefined; }
    if (!draft.videoId) { setVideoUrl(''); setVideoName(''); return undefined; }
    getVideoFile(draft.videoId).then((record) => {
      if (!record?.blob) return;
      const nextUrl = URL.createObjectURL(record.blob);
      if (cancelled) URL.revokeObjectURL(nextUrl);
      else { localUrl = nextUrl; setVideoUrl(nextUrl); setVideoName(record.name || 'Vídeo salvo'); }
    }).catch(() => setError('Não foi possível carregar o vídeo salvo neste navegador.'));
    return () => { cancelled = true; if (localUrl) URL.revokeObjectURL(localUrl); };
  }, [draft.videoId, product.videoUrl]);
  const closeEditor = () => { if (draft.videoId && draft.videoId !== product.videoId) removeVideoFile(draft.videoId).catch(() => {}); onClose(); };
  const set = (field, value) => setDraft((current) => ({ ...current, [field]: value }));
  const setPrice = (index, field, value) => setDraft((current) => ({ ...current, prices: current.prices.map((price, i) => i === index ? { ...price, [field]: value } : price) }));
  const addPrice = () => setDraft((current) => ({ ...current, prices: [...current.prices, { label: '', price: 0 }] }));
  const removePrice = (index) => setDraft((current) => ({ ...current, prices: current.prices.filter((_, i) => i !== index) }));
  const pickVideo = async (file) => {
    if (!file) return;
    setVideoBusy(true); setError('');
    try {
      const saved = await saveVideoFile(file);
      set('videoId', saved.id); set('videoUrl', ''); setVideoName(saved.name);
      setVideoUrl('');
    } catch (err) { setError(err.message || 'Não foi possível carregar o vídeo.'); }
    finally { setVideoBusy(false); }
  };
  const pickImage = async (file) => {
    if (!file) return;
    setBusy(true); setError('');
    try { set('image', await imageToDataUrl(file)); }
    catch (err) { setError(err.message); }
    setBusy(false);
  };
  const submit = (event) => {
    event.preventDefault();
    if (!draft.name.trim()) { setError('Digite o nome do produto.'); return; }
    if (!draft.prices.length) { setError('Adicione pelo menos um preço.'); return; }
    if (draft.prices.some((price) => !String(price.label).trim() || !Number.isFinite(Number(price.price)) || Number(price.price) < 0)) { setError('Confira as opções e os preços. Todos precisam ter nome e preço válido.'); return; }
    const normalizedLabels = draft.prices.map((price) => String(price.label).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR').trim());
    if (new Set(normalizedLabels).size !== normalizedLabels.length) { setError('Cada opção de preço precisa ter um nome diferente.'); return; }
    onSave({ ...draft, name: draft.name.trim(), description: draft.description.trim(), details: String(draft.details || '').trim(), ingredients: String(draft.ingredients || '').trim(), allergens: String(draft.allergens || '').trim(), preparation: String(draft.preparation || '').trim(), videoUrl: String(draft.videoUrl || '').trim(), prices: draft.prices.map((price) => ({ label: String(price.label).trim(), price: Number(price.price) })) });
  };
  return <ModalShell onClose={closeEditor} wide className="editor-modal"><div className="editor-header"><div><div className="eyebrow">PERSONALIZAR ITEM</div><h2>{product.name ? 'Editar produto' : 'Novo produto'}</h2></div><button className="icon-button" onClick={closeEditor} aria-label="Fechar editor"><X/></button></div>
    <form className="editor-form" onSubmit={submit}><div className="editor-image-field"><div className="editor-photo">{draft.image ? <img src={draft.image} alt="Prévia do produto"/> : <ImagePlaceholder category={draft.category}/>}</div><div><b>Foto real do produto</b><p>Escolha uma imagem do celular. A foto será redimensionada para carregar mais rápido.</p><button className="outline-button" type="button" onClick={() => photoRef.current?.click()}><ImagePlus size={16}/>{busy ? 'Processando foto...' : draft.image ? 'Trocar foto' : 'Carregar foto'}</button>{draft.image && <button className="text-button danger-text" type="button" onClick={() => set('image', '')}>Remover foto</button>}<input ref={photoRef} className="hidden" type="file" accept="image/*" onChange={(e) => pickImage(e.target.files?.[0])}/></div></div>
      <div className="form-grid"><label className="span-two">Nome do produto<input autoFocus value={draft.name} onChange={(e) => set('name', e.target.value)} placeholder="Ex.: Vovô Bacon"/></label><label>Categoria<select value={draft.category} onChange={(e) => set('category', e.target.value)}>{categories.filter((item) => item.id !== 'all').map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}</select></label><label>Selo opcional<input value={draft.badge || ''} onChange={(e) => set('badge', e.target.value)} placeholder="Ex.: Mais pedido"/></label><label className="span-two">Descrição curta<textarea value={draft.description} onChange={(e) => set('description', e.target.value)} rows="2" placeholder="Resumo que aparece no cardápio"/></label><label className="span-two">Descrição detalhada<textarea value={draft.details || ''} onChange={(e) => set('details', e.target.value)} rows="4" placeholder="Conte o que torna esse produto especial"/></label><label className="span-two">Ingredientes<textarea value={draft.ingredients || ''} onChange={(e) => set('ingredients', e.target.value)} rows="2" placeholder="Ex.: pão brioche, carne, queijo, molho da casa"/></label><label className="span-two">Alergênicos / observações<textarea value={draft.allergens || ''} onChange={(e) => set('allergens', e.target.value)} rows="2" placeholder="Ex.: contém glúten e leite; pode conter traços de..."/></label><label className="span-two">Detalhes do preparo<textarea value={draft.preparation || ''} onChange={(e) => set('preparation', e.target.value)} rows="2" placeholder="Explique como o produto é montado e servido"/></label></div>
      <section className="product-video-editor"><div><b>Vídeo da montagem</b><p>Envie um vídeo de até 100 MB. O arquivo enviado fica salvo neste navegador. Para clientes verem o vídeo em outros aparelhos, use abaixo um link público direto de MP4 ou conecte o site a um serviço de armazenamento.</p></div>{videoUrl && <video className="product-video-preview" src={videoUrl} controls playsInline preload="metadata"/>}<div className="product-video-actions"><button className="outline-button" type="button" onClick={() => videoRef.current?.click()}>{videoBusy ? 'Salvando vídeo...' : draft.videoId || draft.videoUrl ? 'Trocar vídeo' : 'Enviar vídeo'}</button>{(draft.videoId || draft.videoUrl) && <button className="text-button danger-text" type="button" onClick={() => { set('videoId', ''); set('videoUrl', ''); setVideoUrl(''); setVideoName(''); }}>Remover vídeo</button>}<input ref={videoRef} className="hidden" type="file" accept="video/*" onChange={(e) => { pickVideo(e.target.files?.[0]); e.target.value = ''; }}/></div><label className="video-url-field">Link público direto de vídeo MP4 (para outros aparelhos)<input value={draft.videoUrl || ''} onChange={(e) => { if (e.target.value && draft.videoId && draft.videoId !== product.videoId) removeVideoFile(draft.videoId).catch(() => {}); set('videoUrl', e.target.value); setVideoUrl(e.target.value); if (e.target.value) set('videoId', ''); }} placeholder="https://.../video.mp4" /></label>{videoName && <small className="video-file-name">Arquivo: {videoName}</small>}</section>
      <div className="price-editor-head"><div><h3>Opções e preços</h3><p>Cadastre um preço único ou tamanhos diferentes.</p></div><button type="button" className="outline-button small-button" onClick={addPrice}><Plus size={15}/> Adicionar opção</button></div><div className="price-editor-list">{draft.prices.map((price, index) => <div className="price-editor-row" key={index}><label><span>Nome da opção</span><input value={price.label} onChange={(e) => setPrice(index, 'label', e.target.value)} placeholder="Ex.: 500 ml"/></label><label><span>Preço (R$)</span><input type="number" min="0" step="0.01" value={price.price} onChange={(e) => setPrice(index, 'price', e.target.value)} /></label><button type="button" className="danger-icon" aria-label="Remover opção" disabled={draft.prices.length === 1} onClick={() => removePrice(index)}><Trash2 size={16}/></button></div>)}</div>
      <label className="toggle-setting editor-active"><span><b>Produto disponível no cardápio</b><small>Desative para ocultar temporariamente sem apagar.</small></span><input type="checkbox" checked={draft.active !== false} onChange={(e) => set('active', e.target.checked)}/></label>
      {error && <div className="form-error">{error}</div>}<div className="editor-footer"><button className="outline-button" type="button" onClick={closeEditor}>Cancelar</button><button className="primary-button" type="submit"><Check size={17}/> Salvar produto</button></div>
    </form>
  </ModalShell>;
}
