const isPlainObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
const normalizeLabel = (value) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR').trim();

const isValidPrice = (price) => isPlainObject(price) && typeof price.label === 'string' && price.label.trim().length > 0 &&
  (typeof price.price === 'number' || typeof price.price === 'string') && String(price.price).trim() !== '' &&
  Number.isFinite(Number(price.price)) && Number(price.price) >= 0;

const isValidProduct = (product) => {
  if (!isPlainObject(product) || typeof product.id !== 'string' || !product.id.trim() || typeof product.name !== 'string' ||
      typeof product.category !== 'string' || !Array.isArray(product.prices) || product.prices.length === 0 ||
      !product.prices.every(isValidPrice) ||
      (product.description !== undefined && typeof product.description !== 'string') ||
      (product.active !== undefined && typeof product.active !== 'boolean') ||
      (product.badge !== undefined && typeof product.badge !== 'string') ||
      (product.image !== undefined && typeof product.image !== 'string')) return false;
  const labels = product.prices.map((price) => normalizeLabel(price.label));
  return new Set(labels).size === labels.length;
};

const isValidCategory = (category) => isPlainObject(category) && typeof category.id === 'string' && !!category.id.trim() &&
  typeof category.label === 'string' && !!category.label.trim() &&
  (category.visible === undefined || typeof category.visible === 'boolean');

const isValidCartItem = (item) => isPlainObject(item) && typeof item.key === 'string' && typeof item.id === 'string' &&
  typeof item.name === 'string' && typeof item.category === 'string' && typeof item.variant === 'string' &&
  (item.image === undefined || typeof item.image === 'string') &&
  (typeof item.price === 'number' || typeof item.price === 'string') && String(item.price).trim() !== '' &&
  Number.isFinite(Number(item.price)) && Number(item.price) >= 0 && Number.isInteger(Number(item.qty)) && Number(item.qty) > 0;

export function validateBackup(data) {
  if (!isPlainObject(data) || !Array.isArray(data.products) || !isPlainObject(data.settings)) {
    throw new Error('Esse arquivo não parece ser um backup válido.');
  }
  if (!data.products.every(isValidProduct)) {
    throw new Error('O backup contém produtos ou preços inválidos. O cardápio atual foi preservado.');
  }
  const productIds = data.products.map((product) => product.id);
  if (new Set(productIds).size !== productIds.length) {
    throw new Error('O backup contém IDs de produto duplicados. O cardápio atual foi preservado.');
  }
  if (data.categories !== undefined) {
    if (!Array.isArray(data.categories) || !data.categories.every(isValidCategory)) {
      throw new Error('O backup contém categorias inválidas. O cardápio atual foi preservado.');
    }
    const ids = data.categories.map((category) => category.id);
    if (new Set(ids).size !== ids.length) throw new Error('O backup contém IDs de categoria duplicados. O cardápio atual foi preservado.');
    if (data.products.some((product) => !ids.includes(product.category))) {
      throw new Error('Há produtos ligados a categorias ausentes no backup. O cardápio atual foi preservado.');
    }
  }
  if (data.cart !== undefined) {
    if (!Array.isArray(data.cart) || !data.cart.every(isValidCartItem)) {
      throw new Error('O backup contém itens de carrinho inválidos. O cardápio atual foi preservado.');
    }
    const keys = data.cart.map((item) => item.key);
    if (new Set(keys).size !== keys.length) throw new Error('O backup contém itens de carrinho duplicados. O cardápio atual foi preservado.');
  }
  const stringSettings = ['storeName', 'tagline', 'whatsapp', 'logo', 'address', 'openingHours'];
  if (stringSettings.some((key) => data.settings[key] !== undefined && typeof data.settings[key] !== 'string')) {
    throw new Error('O backup contém configurações da loja inválidas. O cardápio atual foi preservado.');
  }
  if (['deliveryFee', 'minOrder'].some((key) => {
    const value = data.settings[key];
    return value !== undefined && ((typeof value !== 'string' && typeof value !== 'number') || !Number.isFinite(Number(value)) || Number(value) < 0);
  })) throw new Error('O backup contém valores de entrega inválidos. O cardápio atual foi preservado.');
  if (['deliveryEnabled', 'pickupEnabled'].some((key) => data.settings[key] !== undefined && typeof data.settings[key] !== 'boolean')) {
    throw new Error('O backup contém opções de entrega inválidas. O cardápio atual foi preservado.');
  }
  if (data.settings.heroImages !== undefined && (!Array.isArray(data.settings.heroImages) || data.settings.heroImages.length > 10 || !data.settings.heroImages.every((item) => typeof item === 'string'))) {
    throw new Error('O backup contém imagens de capa inválidas. O cardápio atual foi preservado.');
  }
  if (data.likeCounts !== undefined && (!isPlainObject(data.likeCounts) || Object.values(data.likeCounts).some((count) => typeof count !== 'number' || !Number.isFinite(count) || count < 0))) {
    throw new Error('O backup contém contadores de curtidas inválidos. O cardápio atual foi preservado.');
  }
  return data;
}
