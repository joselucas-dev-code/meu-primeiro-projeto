async function imageToDataUrl(file) {
  if (!file || !file.type.startsWith('image/')) throw new Error('Escolha um arquivo de imagem.');
  const loaded = await new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Não foi possível ler essa imagem.')); };
    img.src = url;
  });
  const canvas = document.createElement('canvas');
  const max = 800;
  const scale = Math.min(1, max / Math.max(loaded.width, loaded.height));
  canvas.width = Math.round(loaded.width * scale); canvas.height = Math.round(loaded.height * scale);
  canvas.getContext('2d').drawImage(loaded, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL('image/jpeg', 0.68);
}

export { imageToDataUrl };
