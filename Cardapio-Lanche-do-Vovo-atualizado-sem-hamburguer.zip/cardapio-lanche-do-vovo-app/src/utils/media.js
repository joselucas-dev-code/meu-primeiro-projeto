const DB_NAME = 'ldv_media_v1';
const STORE_NAME = 'videos';

function openMediaDb() {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) return reject(new Error('Este navegador não oferece armazenamento local de vídeos.'));
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME, { keyPath: 'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Não foi possível abrir o armazenamento de vídeos.'));
  });
}

export async function saveVideoFile(file) {
  if (!file || !file.type.startsWith('video/')) throw new Error('Escolha um arquivo de vídeo.');
  if (file.size > 100 * 1024 * 1024) throw new Error('O vídeo precisa ter até 100 MB.');
  const id = `video-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
  const db = await openMediaDb();
  try {
    await new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      transaction.objectStore(STORE_NAME).put({ id, blob: file, name: file.name, type: file.type, size: file.size, savedAt: Date.now() });
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error || new Error('Não foi possível salvar o vídeo.'));
      transaction.onabort = () => reject(transaction.error || new Error('O salvamento do vídeo foi cancelado.'));
    });
  } finally { db.close(); }
  return { id, name: file.name, size: file.size };
}

export async function getVideoFile(id) {
  if (!id) return null;
  const db = await openMediaDb();
  try {
    return await new Promise((resolve, reject) => {
      const request = db.transaction(STORE_NAME, 'readonly').objectStore(STORE_NAME).get(id);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error || new Error('Não foi possível carregar o vídeo.'));
    });
  } finally { db.close(); }
}

export async function removeVideoFile(id) {
  if (!id || !('indexedDB' in window)) return;
  const db = await openMediaDb();
  try {
    await new Promise((resolve, reject) => {
      const request = db.transaction(STORE_NAME, 'readwrite').objectStore(STORE_NAME).delete(id);
      request.onsuccess = resolve;
      request.onerror = () => reject(request.error || new Error('Não foi possível remover o vídeo.'));
    });
  } finally { db.close(); }
}
