import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowRight, BadgeCheck, Bike, Check, ChevronLeft, ChevronRight, Clock3, Heart,
  Search, ShieldCheck, ShoppingBag, ShoppingCart,
  Sparkles, Utensils, Zap,
} from 'lucide-react';
import { CATEGORIES, INITIAL_PRODUCTS } from './data.js';
import { DEFAULT_CATEGORIES, KEYS, money, normalizeSettings, parseMoney, readStorage, slug } from './config.js';
import { imageToDataUrl } from './utils/images.js';
import { validateBackup } from './backup.js';
import { AdminPanel } from './components/AdminPanel.jsx';
import { CartDrawer } from './components/CartDrawer.jsx';
import { CheckoutModal } from './components/CheckoutModal.jsx';
import { StoreLoginPage } from './components/shared.jsx';
import { ProductCard } from './components/ProductCard.jsx';
import { ProductEditor } from './components/ProductEditor.jsx';
import { PromotionsCarousel } from './components/PromotionsCarousel.jsx';
import { ProductDetailsModal } from './components/ProductDetailsModal.jsx';
import { removeVideoFile } from './utils/media.js';

function App() {
  const [products, setProducts] = useState(() => readStorage(KEYS.products, INITIAL_PRODUCTS));
  const [settings, setSettings] = useState(() => normalizeSettings(readStorage(KEYS.settings, {})));
  const [cart, setCart] = useState(() => readStorage(KEYS.cart, []));
  const [category, setCategory] = useState('all');
  const [search, setSearch] = useState('');
  const [cartOpen, setCartOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [storeRoute, setStoreRoute] = useState(() => window.location.hash === '#/loja' || window.location.hash.startsWith('#/loja/'));
  const [storeAuthorized, setStoreAuthorized] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [detailProduct, setDetailProduct] = useState(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [toast, setToast] = useState('');
  const [categories, setCategories] = useState(() => readStorage(KEYS.categories, DEFAULT_CATEGORIES));
  const [likeCounts, setLikeCounts] = useState(() => readStorage(KEYS.likes, {}));
  const [likedThisVisit, setLikedThisVisit] = useState([]);
  // Toda recarga começa na página inicial; a navegação para o cardápio continua funcionando durante a visita.
  const [page, setPage] = useState('home');
  const [heroIndex, setHeroIndex] = useState(0);
  const [checkout, setCheckout] = useState({ name: '', method: 'delivery', address: '', reference: '', payment: 'Pix', note: '' });
  const backupRef = useRef(null);

  useEffect(() => { try { localStorage.setItem(KEYS.products, JSON.stringify(products)); } catch { setToast('O armazenamento está cheio. Exporte um backup e reduza o tamanho das fotos.'); } }, [products]);
  useEffect(() => { try { localStorage.setItem(KEYS.settings, JSON.stringify(settings)); } catch { setToast('Não foi possível salvar mais dados neste navegador. Exporte um backup.'); } }, [settings]);
  useEffect(() => { try { localStorage.setItem(KEYS.cart, JSON.stringify(cart)); } catch { setToast('Não foi possível salvar o carrinho no navegador.'); } }, [cart]);
  useEffect(() => { try { localStorage.setItem(KEYS.categories, JSON.stringify(categories)); } catch { setToast('Não foi possível salvar as categorias neste navegador.'); } }, [categories]);
  useEffect(() => { try { localStorage.setItem(KEYS.likes, JSON.stringify(likeCounts)); } catch {} }, [likeCounts]);
  useEffect(() => {
    // Rotas públicas e área administrativa separadas por hash.
    // A área da loja não é anunciada nem linkada pela interface do cliente.
    if (!window.location.hash) {
      window.history.replaceState(null, '', `${window.location.pathname}${window.location.search}#/`);
    }
    const syncPage = () => {
      const hash = window.location.hash || '#/';
      if (hash === '#/loja' || hash.startsWith('#/loja/')) {
        setStoreRoute(true);
        setPage('home');
        return;
      }
      setStoreRoute(false);
      setStoreAuthorized(false);
      setAdminOpen(false);
      setEditingProduct(null);
      setDetailProduct(null);
      setPage(hash.includes('/cardapio') ? 'menu' : 'home');
    };
    syncPage();
    window.addEventListener('hashchange', syncPage);
    return () => window.removeEventListener('hashchange', syncPage);
  }, []);
  const heroImages = settings.heroImages.length ? settings.heroImages : [];
  useEffect(() => { setHeroIndex(0); }, [heroImages.length]);
  useEffect(() => { if (heroImages.length < 2) return; const timer = setInterval(() => setHeroIndex((index) => (index + 1) % heroImages.length), 5000); return () => clearInterval(timer); }, [heroImages.length]);
  useEffect(() => {
    if (!toast) return;
    const timeout = setTimeout(() => setToast(''), 3000);
    return () => clearTimeout(timeout);
  }, [toast]);

  const visibleCategories = useMemo(() => [{ id: 'all', label: 'Tudo' }, ...categories.filter((item) => item.id !== 'all' && item.visible !== false)], [categories]);
  const productCategories = useMemo(() => categories.filter((item) => item.id !== 'all'), [categories]);
  const visibleProducts = useMemo(() => products.filter((product) => {
    const matchesCategory = category === 'all' || product.category === category;
    const query = search.trim().toLocaleLowerCase('pt-BR');
    const matchesQuery = !query || `${product.name} ${product.description} ${product.category}`.toLocaleLowerCase('pt-BR').includes(query);
    return product.active !== false && matchesCategory && matchesQuery;
  }), [products, category, search]);
  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const deliveryFee = checkout.method === 'delivery' ? parseMoney(settings.deliveryFee) : 0;
  const total = subtotal + deliveryFee;

  const notify = (message) => setToast(message);
  const navigate = (destination) => { window.location.hash = destination === 'menu' ? '/cardapio' : '/'; setPage(destination); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const updateSettings = (patch) => {
    if (patch.deliveryEnabled === false && !settings.pickupEnabled) { notify('Mantenha delivery ou retirada ativado.'); return; }
    if (patch.pickupEnabled === false && !settings.deliveryEnabled) { notify('Mantenha delivery ou retirada ativado.'); return; }
    setSettings((current) => normalizeSettings({ ...current, ...patch }));
  };
  const toggleLike = (id) => {
    const alreadyLiked = likedThisVisit.includes(id);
    setLikedThisVisit((current) => alreadyLiked ? current.filter((item) => item !== id) : [...current, id]);
    setLikeCounts((current) => ({ ...current, [id]: Math.max(0, (Number(current[id]) || 0) + (alreadyLiked ? -1 : 1)) }));
  };
  const comparableLabel = (value) => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR').trim();
  const addCategory = (name) => {
    const label = String(name || '').trim();
    if (!label) return false;
    if (categories.some((item) => comparableLabel(item.label) === comparableLabel(label))) return false;
    const normalized = comparableLabel(label).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'categoria';
    const baseId = `cat-${normalized}`; let id = baseId; let suffix = 2;
    while (categories.some((item) => item.id === id)) { id = `${baseId}-${suffix}`; suffix += 1; }
    setCategories((items) => [...items, { id, label, visible: true }]);
    return true;
  };
  const updateCategory = (id, patch) => {
    if (patch.label !== undefined) {
      const nextLabel = String(patch.label).trim();
      if (!nextLabel || categories.some((item) => item.id !== id && comparableLabel(item.label) === comparableLabel(nextLabel))) {
        notify('Use um nome de categoria diferente e não vazio.'); return false;
      }
      patch = { ...patch, label: nextLabel };
    }
    setCategories((items) => items.map((item) => item.id === id ? { ...item, ...patch } : item));
    return true;
  };
  const removeCategory = (id) => {
    const target = categories.find((item) => item.id === id);
    if (!target || id === 'all') return;
    const remaining = categories.filter((item) => item.id !== id && item.id !== 'all');
    const fallback = remaining.find((item) => item.id === 'classicos') || remaining[0] || DEFAULT_CATEGORIES.find((item) => item.id !== id && item.id !== 'all');
    if (!window.confirm(`Excluir a categoria "${target.label}"? Os produtos serão movidos para ${fallback?.label || 'outra categoria'}.`)) return;
    setCategories((items) => {
      const next = items.filter((item) => item.id !== id);
      if (!next.some((item) => item.id !== 'all') && fallback) next.push({ ...fallback, visible: true });
      return next;
    });
    if (fallback) setProducts((items) => items.map((product) => product.category === id ? { ...product, category: fallback.id } : product));
    if (category === id) setCategory('all');
    notify('Categoria excluída');
  };
  const uploadHeroImages = async (files) => {
    const current = Array.isArray(settings.heroImages) ? settings.heroImages : [];
    const available = Math.max(0, 10 - current.length);
    if (!available) { notify('O carrossel já tem 10 imagens.'); return; }
    try {
      const additions = await Promise.all(Array.from(files || []).slice(0, available).map(imageToDataUrl));
      updateSettings({ heroImages: [...current, ...additions] });
      notify('Imagens da capa adicionadas');
    } catch (error) { notify(error.message || 'Não foi possível carregar as imagens.'); }
  };
  const addToCart = (product, priceOption) => {
    const key = `${product.id}::${priceOption.label}`;
    setCart((items) => {
      const existing = items.find((item) => item.key === key);
      return existing
        ? items.map((item) => item.key === key ? { ...item, qty: item.qty + 1 } : item)
        : [...items, { key, id: product.id, name: product.name, category: product.category, variant: priceOption.label, price: Number(priceOption.price), qty: 1, image: product.image || '' }];
    });
    notify(`${product.name} adicionado ao carrinho`);
  };
  const changeQty = (key, delta) => setCart((items) => items.map((item) => item.key === key ? { ...item, qty: item.qty + delta } : item).filter((item) => item.qty > 0));
  const deleteCartItem = (key) => setCart((items) => items.filter((item) => item.key !== key));
  const saveProduct = (product) => {
    const previousProduct = products.find((item) => item.id === product.id);
    if (previousProduct?.videoId && previousProduct.videoId !== product.videoId) removeVideoFile(previousProduct.videoId).catch(() => {});
    setProducts((items) => {
      const index = items.findIndex((item) => item.id === product.id);
      if (index < 0) return [...items, product];
      return items.map((item) => item.id === product.id ? product : item);
    });
    setEditingProduct(null);
    notify('Produto salvo!');
  };
  const deleteProduct = (id) => {
    const target = products.find((product) => product.id === id);
    if (!target || !window.confirm(`Excluir “${target.name}” do cardápio?`)) return;
    setProducts((items) => items.filter((product) => product.id !== id));
    if (target.videoId) removeVideoFile(target.videoId).catch(() => {});
    notify('Produto excluído');
  };
  const startAddProduct = () => setEditingProduct({ id: slug(), name: '', category: 'classicos', description: '', details: '', ingredients: '', allergens: '', preparation: '', image: '', videoId: '', videoUrl: '', active: true, prices: [{ label: 'Único', price: 0 }], badge: '' });
  const uploadLogo = async (file) => {
    try { updateSettings({ logo: await imageToDataUrl(file) }); notify('Logo atualizada'); }
    catch (error) { notify(error.message); }
  };
  const downloadBackup = () => {
    const data = { app: 'Lanche do Vovô', version: 2, exportedAt: new Date().toISOString(), settings, products, cart, categories, likeCounts };
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a'); a.href = url; a.download = 'backup-lanche-do-vovo.json'; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    notify('Backup exportado');
  };
  const importBackup = async (file) => {
    try {
      const data = validateBackup(JSON.parse(await file.text()));
      if (!window.confirm('Importar esse backup vai substituir o cardápio, categorias, curtidas e configurações atuais. Continuar?')) return;
      const importedCategories = Array.isArray(data.categories) ? data.categories : DEFAULT_CATEGORIES;
      setProducts(data.products);
      setCategories(importedCategories);
      setSettings(normalizeSettings(data.settings));
      setCart(Array.isArray(data.cart) ? data.cart : []);
      setLikeCounts(data.likeCounts && typeof data.likeCounts === 'object' ? data.likeCounts : {});
      setLikedThisVisit([]);
      notify('Backup importado com sucesso');
    } catch (error) { notify(error.message || 'Não foi possível importar o backup.'); }
  };
  const openWhatsApp = () => {
    if (cart.length === 0) { notify('Adicione pelo menos um item ao carrinho.'); return; }
    const phone = String(settings.whatsapp || '').replace(/\D/g, '');
    if (!phone || phone.length < 10) { notify('A loja ainda não configurou o WhatsApp para receber pedidos.'); setCheckoutOpen(false); setCartOpen(false); return; }
    if (!checkout.name.trim()) { notify('Informe seu nome para continuar.'); return; }
    if (checkout.method === 'delivery' && !checkout.address.trim()) { notify('Informe o endereço de entrega.'); return; }
    if (parseMoney(settings.minOrder) > 0 && subtotal < parseMoney(settings.minOrder)) { notify(`O pedido mínimo é ${money(parseMoney(settings.minOrder))}.`); return; }
    const lines = cart.map((item) => `• ${item.qty}x ${item.name} (${item.variant}) — ${money(item.price * item.qty)}`);
    const order = [
      `*NOVO PEDIDO — ${settings.storeName}*`, '', `*Cliente:* ${checkout.name.trim()}`,
      `*Tipo:* ${checkout.method === 'delivery' ? 'Entrega' : 'Retirada no local'}`,
      ...(checkout.method === 'delivery' ? [`*Endereço:* ${checkout.address.trim()}`, ...(checkout.reference.trim() ? [`*Referência:* ${checkout.reference.trim()}`] : [])] : []),
      '', '*Itens do pedido:*', ...lines, '', `*Subtotal:* ${money(subtotal)}`,
      ...(checkout.method === 'delivery' && deliveryFee > 0 ? [`*Taxa de entrega:* ${money(deliveryFee)}`] : []),
      `*TOTAL: ${money(total)}*`, `*Pagamento:* ${checkout.payment}`,
      ...(checkout.note.trim() ? ['', `*Observações:* ${checkout.note.trim()}`] : []), '', 'Pedido enviado pelo cardápio digital.'
    ].join('\n');
    const whatsappWindow = window.open(`https://wa.me/${phone}?text=${encodeURIComponent(order)}`, '_blank');
    if (!whatsappWindow) { notify('O navegador bloqueou o WhatsApp. Permita a abertura da janela e tente novamente.'); return; }
    try { whatsappWindow.opener = null; } catch {}
    setCheckoutOpen(false);
  };

  const leaveStore = () => {
    setAdminOpen(false);
    setStoreAuthorized(false);
    setStoreRoute(false);
    setEditingProduct(null);
    window.location.hash = '/';
    setPage('home');
  };

  if (storeRoute) {
    return <div className="store-route-shell">
      {adminOpen && storeAuthorized ? <>
        <AdminPanel settings={settings} products={products} categories={categories} productCategories={productCategories} onClose={leaveStore} onSettings={updateSettings} onLogo={uploadLogo} onHeroImages={uploadHeroImages} onCategoryAdd={addCategory} onCategoryUpdate={updateCategory} onCategoryRemove={removeCategory} onEdit={(product) => setEditingProduct({ ...product, prices: product.prices.map((price) => ({ ...price })) })} onAdd={startAddProduct} onDelete={deleteProduct} onExport={downloadBackup} onImport={() => backupRef.current?.click()}/>
        {editingProduct && <ProductEditor product={editingProduct} categories={productCategories} onClose={() => setEditingProduct(null)} onSave={saveProduct}/>}
        <input ref={backupRef} className="hidden" type="file" accept="application/json,.json" onChange={(e) => { const file = e.target.files?.[0]; if (file) importBackup(file); e.target.value = ''; }}/>
      </> : <StoreLoginPage storeName={settings.storeName} logo={settings.logo} onBack={leaveStore} onSuccess={() => { setStoreAuthorized(true); setAdminOpen(true); }}/>} 
      {toast && <div className="toast" role="status"><BadgeCheck size={17}/>{toast}</div>}
    </div>;
  }

  return <div className="app-shell">
    <div className="announcement"><Sparkles size={14}/> Hambúrguer artesanal, batata crocante e milk-shake gelado <span>·</span> Feito na hora</div>
    <header className="site-header">
      <a className="brand" href="#/" onClick={(event) => { event.preventDefault(); navigate('home'); }}>
        <img src={settings.logo || '/logo-lanche-do-vovo.jpg'} alt="Logo Lanche do Vovô" onError={(e) => { e.currentTarget.src = '/logo-lanche-do-vovo.jpg'; }}/>
        <span><strong>{settings.storeName}</strong><small>{settings.tagline}</small></span>
      </a>
      <nav className="site-nav" aria-label="Navegação principal">
        <button type="button" className={page === 'home' ? 'active' : ''} onClick={() => navigate('home')}>Início</button>
        <button type="button" className={page === 'menu' ? 'active' : ''} onClick={() => navigate('menu')}>Cardápio</button>
      </nav>
      <div className="header-search"><Search size={18}/><input value={search} onChange={(e) => { setSearch(e.target.value); if (e.target.value && page !== 'menu') navigate('menu'); }} placeholder="O que vai matar sua fome hoje?" aria-label="Buscar produtos"/><kbd>Buscar</kbd></div>
      <div className="header-actions">
        <button className="cart-header" onClick={() => setCartOpen(true)}><ShoppingBag size={18}/><span className="cart-header-label">Meu pedido</span><b>{cartCount}</b></button>
      </div>
    </header>

    <main id="top" className={`page-view page-${page}`}>
      {page === 'home' ? <>
        <section key="home-hero" className="hero container">
          <div className="hero-content">
            <div className="eyebrow"><span className="eyebrow-dot"/> SABOR DE VERDADE</div>
            <h1>A fome bateu?<br/><em>O Vovô resolve.</em></h1>
            <p>Do clássico caprichado ao monstrão que desafia a fome. Escolha seus favoritos e peça sem complicação.</p>
            <div className="hero-actions"><button className="primary-button" onClick={() => navigate('menu')}>Ver cardápio <ArrowRight size={17}/></button><div className="hero-note"><span className="avatar-stack"><i>🍔</i><i>🍟</i><i>🥤</i></span><span><b>Seu próximo favorito</b><small>está a um clique</small></span></div></div>
            <div className="hero-perks"><span><Zap size={16}/> Preparado na hora</span><span><ShieldCheck size={16}/> Pedido direto com a loja</span></div>
          </div>
          {heroImages.length ? <div className="hero-art hero-photo-carousel" aria-label="Carrossel de fotos do Lanche do Vovô">
            <img key={`${heroIndex}-${heroImages[heroIndex]}`} className="hero-carousel-image" src={heroImages[heroIndex]} alt={`Foto do Lanche do Vovô ${heroIndex + 1}`} fetchPriority="high"/>
            <div className="hero-carousel-vignette"/>
            <div className="hero-carousel-caption"><span className="caption-rule"/><span>FEITO COM CARINHO. SABOR DE VERDADE.</span></div>
            <span className="hero-carousel-index">{String(heroIndex + 1).padStart(2, '0')} <i>/</i> LANCHES DO VOVÔ</span>
            {heroImages.length > 1 && <div className="hero-carousel-controls"><button type="button" onClick={() => setHeroIndex((index) => (index - 1 + heroImages.length) % heroImages.length)} aria-label="Imagem anterior"><ChevronLeft size={18}/></button><span>{String(heroIndex + 1).padStart(2, '0')} / {String(heroImages.length).padStart(2, '0')}</span><button type="button" onClick={() => setHeroIndex((index) => (index + 1) % heroImages.length)} aria-label="Próxima imagem"><ChevronRight size={18}/></button></div>}
          </div> : <div className="hero-art" aria-label="Ilustração de hambúrguer"><div className="hero-art-glow"/><div className="hero-art-orbit orbit-one"/><div className="hero-art-orbit orbit-two"/><div className="hero-burger">🍔</div><span className="floating-tag tag-one">Feito na hora <Check size={13}/></span><span className="floating-tag tag-two">Sabor de vó ❤️</span><span className="art-spark spark-one">✳</span><span className="art-spark spark-two">✦</span></div>}
        </section>

        <section className="trust-strip container"><div><span className="trust-icon"><Utensils size={19}/></span><span><b>Capricho em cada mordida</b><small>Ingredientes bem escolhidos</small></span></div><div><span className="trust-icon"><Clock3 size={19}/></span><span><b>Feito na hora</b><small>Do nosso balcão pra você</small></span></div><div><span className="trust-icon"><Bike size={19}/></span><span><b>Entrega ou retirada</b><small>Combine no fechamento</small></span></div></section>
        <section className="home-menu-prompt container"><div className="home-menu-prompt-art"><span>🍔</span><span>🍟</span><span>🥤</span></div><div><div className="eyebrow">ESCOLHA SUA FOME</div><h2>Tem um Vovô esperando <em>por você.</em></h2><p>Veja os clássicos, os especiais, os monstrões e os milk-shakes da casa.</p></div><button className="primary-button" onClick={() => navigate('menu')}>Explorar cardápio <ArrowRight size={17}/></button></section>
      </> : <>
        <section key="menu-section" className="menu-section container menu-page-section" id="menu-products">
          <div className="menu-page-heading"><button className="back-home-link" onClick={() => navigate('home')}><ChevronLeft size={16}/> Voltar ao início</button><div className="eyebrow">ESCOLHA SUA FOME</div><h1>Nosso <em>cardápio</em></h1><p>Clássicos, especiais e combinações para deixar o dia melhor.</p></div>
          <PromotionsCarousel promotions={settings.promotions || []} products={products} onOpenProduct={setDetailProduct} onBrowse={() => { setCategory('all'); setSearch(''); document.getElementById('menu-products')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }}/><div className="section-heading"><div><div className="eyebrow">DO NOSSO BALCÃO PRA VOCÊ</div><h2>Encontre seu <em>favorito</em></h2></div><div className="mobile-search"><Search size={16}/><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar no cardápio" aria-label="Pesquisar no cardápio"/></div><div className="results-count">{visibleProducts.length} {visibleProducts.length === 1 ? 'opção' : 'opções'}</div></div>
          <div className="category-bar">
            {visibleCategories.map((item) => <button key={item.id} className={`category-pill ${category === item.id ? 'active' : ''}`} onClick={() => { setCategory(item.id); setMobileNavOpen(false); }}>
              {item.id === 'all' ? <Sparkles size={15}/> : item.id === 'shakes' ? '🥤' : item.id === 'porcoes' ? '🍟' : item.id === 'crispy' ? '🍗' : '🍔'} {item.label}
            </button>)}
          </div>
          {visibleProducts.length ? <div className="product-grid">{visibleProducts.map((product) => <ProductCard key={product.id} product={product} categories={productCategories} onAdd={addToCart} onDetails={setDetailProduct} isFavorite={likedThisVisit.includes(product.id)} likeCount={likeCounts[product.id] || 0} onFavorite={() => toggleLike(product.id)}/>)}</div> : <div className="empty-search"><Search size={28}/><h3>Nenhum item encontrado</h3><p>Tente outro nome ou selecione outra categoria.</p><button className="outline-button" onClick={() => { setSearch(''); setCategory('all'); }}>Limpar filtros</button></div>}
        </section>
        <section className="closing-banner container menu-closing-banner"><div className="closing-badge"><Heart size={18} fill="currentColor"/></div><div><span>FEITO COM CARINHO</span><h2>Seu pedido, seu jeito.</h2><p>Escolha seus itens e envie o pedido direto para a loja pelo WhatsApp.</p></div><button className="closing-button" onClick={() => setCartOpen(true)}>Revisar meu pedido <ArrowRight size={17}/></button></section>
      </>}
    </main>

    <footer className="site-footer"><div className="footer-brand"><img src={settings.logo || '/logo-lanche-do-vovo.jpg'} alt="" onError={(e) => { e.currentTarget.src = '/logo-lanche-do-vovo.jpg'; }}/><div><b>{settings.storeName}</b><small>{settings.tagline}</small></div></div><div className="footer-center">© {new Date().getFullYear()} {settings.storeName}. Feito com carinho e fome.</div><div className="footer-signature">Feito com fome e carinho <span>♥</span></div></footer>

    {cartCount > 0 && !cartOpen && <button className="floating-cart" onClick={() => setCartOpen(true)}><span className="floating-cart-icon"><ShoppingCart size={19}/><i>{cartCount}</i></span><span><small>Seu pedido</small><b>{money(subtotal)}</b></span><span className="floating-cart-arrow"><ArrowRight size={18}/></span></button>}
    {cartOpen && <CartDrawer cart={cart} subtotal={subtotal} settings={settings} onClose={() => setCartOpen(false)} onChangeQty={changeQty} onRemove={deleteCartItem} onBrowse={() => { setCartOpen(false); navigate('menu'); }} onCheckout={() => { setCartOpen(false); setCheckoutOpen(true); }}/>} 
    {adminOpen && <AdminPanel settings={settings} products={products} categories={categories} productCategories={productCategories} onClose={() => setAdminOpen(false)} onSettings={updateSettings} onLogo={uploadLogo} onHeroImages={uploadHeroImages} onCategoryAdd={addCategory} onCategoryUpdate={updateCategory} onCategoryRemove={removeCategory} onEdit={(product) => setEditingProduct({ ...product, prices: product.prices.map((price) => ({ ...price })) })} onAdd={startAddProduct} onDelete={deleteProduct} onExport={downloadBackup} onImport={() => backupRef.current?.click()}/>} 
    {editingProduct && <ProductEditor product={editingProduct} categories={productCategories} onClose={() => setEditingProduct(null)} onSave={saveProduct}/>}
    {detailProduct && <ProductDetailsModal product={products.find((item) => item.id === detailProduct.id) || detailProduct} categories={productCategories} onClose={() => setDetailProduct(null)} onAdd={addToCart}/>} 
    {checkoutOpen && <CheckoutModal checkout={checkout} setCheckout={setCheckout} settings={settings} cart={cart} subtotal={subtotal} total={total} deliveryFee={deliveryFee} onClose={() => setCheckoutOpen(false)} onSend={openWhatsApp}/>} 
    <input ref={backupRef} className="hidden" type="file" accept="application/json,.json" onChange={(e) => { const file = e.target.files?.[0]; if (file) importBackup(file); e.target.value = ''; }}/>
    {toast && <div className="toast" role="status"><BadgeCheck size={17}/>{toast}</div>}
  </div>;
}

export default App;
