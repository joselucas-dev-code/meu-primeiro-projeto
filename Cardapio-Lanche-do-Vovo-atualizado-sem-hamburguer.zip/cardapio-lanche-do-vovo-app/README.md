# Lanche do Vovô — Cardápio Digital

Aplicação React + Vite para cardápio de hamburgueria, com catálogo de produtos, busca, categorias, carrinho, fechamento de pedido via WhatsApp, painel administrativo local, edição de preços e opções, upload de fotos e backup JSON.

## Requisitos

- Node.js 20.19+ ou 22.12+ (no Termux, verifique a versão disponível com `node --version`).
- Internet apenas na primeira instalação das dependências (`npm install`). O servidor local não precisa publicar o site na internet.

## Rodar no Android pelo Termux

1. Baixe e extraia `Cardapio-Lanche-do-Vovo-App-integrado.zip` dentro de Downloads.
2. No Termux, execute:

```bash
pkg install nodejs unzip -y
cd ~/storage/downloads
unzip Cardapio-Lanche-do-Vovo-App-integrado.zip
cd cardapio-lanche-do-vovo-app
npm install
npm run dev -- --host 0.0.0.0
```

3. Deixe o Termux aberto e acesse no Chrome do mesmo celular: `http://127.0.0.1:5173`.
4. Para parar o servidor, volte ao Termux e pressione `Ctrl + C`.

Se preferir iniciar depois de instalar as dependências, rode `bash iniciar.sh` dentro da pasta. Não abra apenas o `index.html`: esta aplicação usa React/Vite e precisa do servidor de desenvolvimento. A primeira instalação precisa de internet para baixar as dependências.

## Primeira configuração

- Acesse a área administrativa diretamente pela URL `#/loja` — localmente, `http://127.0.0.1:5173/#/loja`; no site publicado, `https://seu-site.com/#/loja`. Ela não aparece como link nem botão na interface pública do cliente.
- Em **Dados da loja**, configure o número de WhatsApp com país + DDD + número, apenas números. Exemplo fictício: `5521999999999`.
- Entre em **Produtos** para editar nomes, descrições, categorias, opções/tamanhos e valores. Na edição do produto, preencha também descrição detalhada, ingredientes, alergênicos, preparo e vídeo da montagem.
- Na aba **Promoções**, cadastre até 6 banners com imagem, título, texto e link para um produto. Eles aparecem antes da lista de produtos e passam automaticamente.
- Carregue fotos reais dos produtos e, se quiser, uma logo.
- Faça um backup em **Backup** depois de personalizar.

## Recursos

- 33 produtos/opções principais pré-cadastrados a partir das referências fornecidas.
- Busca e filtros por categoria.
- Curtidas/favoritos por produto, com contagem salva localmente e ação de curtir/descurtir durante a visita.
- Página do cliente com início e cardápio por hash (`#/` e `#/cardapio`) e uma entrada administrativa separada em `#/loja`, sem atalho na interface pública.
- Carrossel automático na capa (até 10 imagens, com controles e temporizador); a ilustração original continua sendo exibida até você adicionar fotos.
- Novo carrossel automático de promoções antes dos produtos, com até 6 campanhas configuráveis no painel administrativo.
- Ficha detalhada por produto com preço/opções, descrição ampliada, ingredientes, alergênicos, preparo e vídeo de montagem.
- Upload de vídeo por produto (até 100 MB), salvo no IndexedDB deste navegador, separado do localStorage para não consumir a mesma cota de armazenamento.
- Gerenciamento de categorias: adicionar, renomear, ocultar filtros e excluir categorias movendo produtos para uma categoria de destino.
- Login visual próprio para a loja e painel administrativo amplo, com senha validada localmente no frontend (não é autenticação segura de servidor).
- Seletor de tamanho/opção e preços diferentes por opção.
- Carrinho com quantidades, remoção, subtotal, taxa de entrega estimada e total.
- Fechamento com nome, entrega/retirada, endereço, referência, pagamento e observações.
- Montagem automática de mensagem de pedido no WhatsApp.
- Painel administrativo para editar, ocultar, adicionar e excluir produtos.
- Upload de fotos locais com redimensionamento para reduzir o peso.
- Exportação/importação de backup JSON, incluindo fotos, categorias, campanhas promocionais, imagens da capa e contagens de curtidas, com validação antes de substituir dados.
- Persistência de produtos/configurações com `localStorage` e arquivos de vídeo no IndexedDB local.

## Área administrativa e segurança

Abra a área administrativa diretamente pela URL `#/loja`; ela não é linkada no cardápio do cliente. A senha inicial continua sendo `vovo2026`, definida em `src/config.js`.

**Limitação importante:** esta versão não possui backend. A senha é validada no frontend e os dados são guardados no `localStorage` do navegador atual. Portanto, a separação melhora a navegação, mas não oferece segurança real contra inspeção do código, e alterações não são sincronizadas automaticamente com os dispositivos dos clientes. Para uma loja publicada com proteção real, será necessário adicionar autenticação e banco de dados no servidor (ou serviço equivalente) antes de considerar o painel seguro em produção.

## Limites importantes desta versão

Esta é uma aplicação frontend local. Dados e fotos ficam no armazenamento do navegador/dispositivo. Os vídeos enviados ficam no IndexedDB do mesmo navegador e **não são incluídos no backup JSON**; ao migrar para outro aparelho, será necessário enviar esses vídeos novamente. Usar outro domínio ou limpar os dados do navegador também pode tornar os vídeos indisponíveis. O WhatsApp abre com o pedido preenchido, mas a pessoa ainda precisa tocar em enviar dentro do WhatsApp. Não há pagamentos online, controle de estoque multiusuário, banco de dados na nuvem, painel de pedidos em tempo real ou sincronização automática entre dispositivos. Para publicar um link compartilhável com dados sincronizados, é necessário hospedar e integrar um backend/banco de dados.
