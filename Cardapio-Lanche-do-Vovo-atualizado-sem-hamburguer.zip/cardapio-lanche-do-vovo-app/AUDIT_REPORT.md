# Relatório — Integração do Cardápio Lanche do Vovô

## Objetivo

Adicionar ao projeto Lanche do Vovô os recursos funcionais que existiam no projeto de referência, sem substituir o catálogo, a identidade visual, as cores, a logo ou os dados originais do Vovô.

## Funcionalidades integradas

- Navegação entre página inicial e página exclusiva de cardápio por hash (`#/` e `#/cardapio`), com links de retorno e animação de entrada.
- Carrossel configurável de até 10 fotos na capa, com mudança automática a cada cinco segundos e controles anterior/próxima. Se nenhuma foto for configurada, o desenho original do hambúrguer continua sendo mostrado.
- Gerenciamento de categorias no painel: adicionar, renomear, mostrar/ocultar filtros e excluir categoria movendo seus produtos para uma categoria existente.
- Contagem de curtidas por produto persistida localmente; o estado de curtir/descurtir vale para a visita atual, de acordo com o comportamento da referência.
- Área administrativa separada em `#/loja`, com tela de login própria; os botões de acesso à loja foram removidos do cabeçalho e do rodapé do cliente.
- Validação do backup antes da importação, incluindo produtos, opções de preço, IDs, categorias, itens do carrinho, configurações, fotos da capa e contagens de curtidas.
- Verificação para não permitir desativar entrega e retirada ao mesmo tempo, validação de opções de preço duplicadas e tratamento de popup bloqueado no envio para o WhatsApp.
- Código reorganizado em `config.js`, `utils/`, `components/` e `tests/`.

## Preservação visual e de dados

- `src/data.js`: idêntico ao arquivo enviado originalmente.
- `index.html`: idêntico ao arquivo enviado originalmente.
- `public/logo-lanche-do-vovo.jpg`: idêntica byte a byte à logo original.
- `src/styles.css`: as regras originais foram preservadas e um bloco adicional foi acrescentado ao final para o fundo com grade em perspectiva, cores mais vivas e o redesenho responsivo do login e do painel da loja.
- Não foram copiadas fotos nem logos do projeto BLACKOUT BURGER.
- As chaves existentes de `localStorage` para produtos, configurações e carrinho foram mantidas para preservar dados já gravados nos navegadores. Foram adicionadas chaves separadas para categorias e curtidas.

## Correções desta revisão

- A rota `#/cardapio` é preservada na atualização, e a rota `#/loja` abre diretamente a tela de login administrativa, sem mostrar a página do cliente por trás.
- Em telas de celular, o CSS não deixa mais o carrossel da capa invisível: somente a ilustração decorativa segue oculta no breakpoint mobile, e o carrossel configurado recebe largura e altura próprias.

## Verificações executadas

- Testes de backup: **8 aprovados, 0 falhas**, via `npm test` / `node --test`.
- Parse sintático de 14 arquivos JavaScript/JSX/configuração.
- Verificação de 28 imports locais, com arquivos de destino e exports nomeados correspondentes.
- Parser PostCSS: CSS aceito sem erro de sintaxe.
- Confirmação por comparação binária dos arquivos `src/data.js`, `index.html` e da logo original.

## Validação que permanece pendente

Os testes unitários existentes foram executados nesta revisão: **8 aprovados, 0 falhas**. A instalação de dependências com `npm install --no-audit --no-fund` excedeu o limite de execução disponível; por isso, `vite` não ficou instalado e **não foi possível executar `npm run build` nem validar o visual em um navegador**. No Termux/PC, instale as dependências e execute `npm test` e `npm run build` para completar essa validação.

## Nota de segurança

A senha padrão do painel é `vovo2026`, definida em `src/config.js`. A rota administrativa não é linkada na interface do cliente e exige a senha no frontend, mas isso é apenas uma barreira visual: a senha pode ser encontrada no código enviado ao navegador. Para proteger a administração em produção, implemente autenticação e autorização no servidor e armazene produtos/configurações em um banco de dados remoto.

## Limitações funcionais que permanecem

Os dados, fotos e contagens de curtidas continuam locais a cada navegador/dispositivo. O pedido é preparado no WhatsApp, e o cliente precisa confirmar o envio dentro do WhatsApp. Não existe backend para sincronização entre dispositivos, pagamentos ou gestão centralizada de pedidos.
