#!/data/data/com.termux/files/usr/bin/bash
set -e
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Node.js/NPM não encontrado. Instale com: pkg install nodejs -y"
  exit 1
fi
if [ ! -d node_modules ]; then
  echo "Instalando dependências do cardápio..."
  npm install
fi
echo "Abrindo o servidor local do Lanche do Vovô..."
echo "Depois, abra http://127.0.0.1:5173 no navegador do celular."
npm run dev -- --host 0.0.0.0
